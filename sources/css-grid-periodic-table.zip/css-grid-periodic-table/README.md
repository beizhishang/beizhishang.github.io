# CSS Grid: Periodic Table

A Pen created on CodePen.io. Original URL: [https://codepen.io/oliviale/pen/ZmvPPd](https://codepen.io/oliviale/pen/ZmvPPd).

My very first CSS Grid Experiment!

So I can't actually group them together in a cluster like an actual periodic table or it wouldn't make sense or would look too forced 😔

One of my fondest memories of 2018 is when I found the resolve to deactivate Facebook, only to have my team lead tell me I'm in charge of Facebook ads a week later.  No escape from Zuckerberg!