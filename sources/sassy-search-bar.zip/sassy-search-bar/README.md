# Sassy Search Bar 💁

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/xxXJbqq](https://codepen.io/Hyperplexed/pen/xxXJbqq).

