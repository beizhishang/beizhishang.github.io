# Nested sortable list (category tree)

A Pen created on CodePen.io. Original URL: [https://codepen.io/i_5an/pen/MWzYdqm](https://codepen.io/i_5an/pen/MWzYdqm).

