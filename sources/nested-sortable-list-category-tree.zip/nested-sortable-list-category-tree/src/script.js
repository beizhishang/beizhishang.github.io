const categoryLists = document.querySelectorAll("ul");
const listToggles = document.querySelectorAll(".list-toggle");

listToggles.forEach((toggle) => {
  toggle.addEventListener("click", () => {
    toggleItem(toggle);
  });
});

function toggleItem(el) {
  let list = el.parentNode.nextElementSibling;
  list.hidden = !list.hidden;
  el.innerText =
    el.innerText === "expand_more" ? "chevron_right" : "expand_more";
}

for (let i = 0; i < categoryLists.length; i++) {
  new Sortable(categoryLists[i], {
    group: "nested",
    handle: ".handle",
    animation: 275,
    fallbackOnBody: true,
    forceFallback: true,
    swapThreshold: 0.65,
    direction: "vertical",

    // Changed sorting within list
    onUpdate: function (evt) {
      let listOrder, data;
      
      listOrder = this.toArray(evt.to);

      
      data = {
        listOrder: listOrder
      };
      // Send AJAX and update order in the backend
      // sendAJAX("some-url", data);
    },

    // Element is dropped into the list from another list
    onAdd: function (evt) {
      let itemId, newParentId, oldListOrder, newListOrder;

      // Update parent_id in the database.
      itemId = evt.item.dataset.id;
      newParentId = evt.to.parentNode.dataset.id;

      oldListOrder = this.toArray(evt.from);
      newListOrder = this.toArray(evt.to);

      // What to do in the backend:
      // 1. Take the moved item by its itemId.
      // 2. Change its parent id to the newParentId.
      // 3. Loop through oldListOrder and update order index.
      // 4. Loop through newListOrder and update order index.
      data = {
        itemId: itemId,
        newParentId: newParentId,
        oldListOrder: oldListOrder,
        newListOrder: newListOrder
      };

      // sendAJAX("some-url", data);
    }
  });
}

function sendAJAX(url, data) {
  fetch(url, {
    method: "POST", // Or 'GET'
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest"
    },
    body: JSON.stringify(data) // Send JSON to the backend
  })
    // Remove the next two "then" if response is not expected
    .then((response) => response.json())
    .then((data) => {
      // Update the content with the received HTML
      document.getElementById(
        "dynamic-content-container" // Use your id here
      ).innerHTML = data.newContent;
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

// AJAX can also be used for "add", "edit" and "delete" buttons,
// but I don't include the code here.
