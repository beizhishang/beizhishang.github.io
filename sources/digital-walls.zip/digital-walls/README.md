# Digital Walls

A Pen created on CodePen.io. Original URL: [https://codepen.io/mxbck/pen/ERNwBy](https://codepen.io/mxbck/pen/ERNwBy).

Inspired by an augmented-reality design I saw on dribbble, I tried to build this screen with modern CSS. It includes CSS grid, Smooth Scrolling and  CSS-only-parallax for 60fps. 