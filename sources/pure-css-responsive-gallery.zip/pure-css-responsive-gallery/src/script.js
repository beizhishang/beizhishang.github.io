/*
This Codepen is in the Public Domain.
You can use it for whatever purpose you like, except evil.
All code comes "as is" and is/was only guaranteed to work on my personal machine at the time I hit the save button (and even then).
*/