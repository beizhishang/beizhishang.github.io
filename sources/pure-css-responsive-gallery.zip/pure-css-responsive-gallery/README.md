# Pure CSS responsive gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/pieter-biesemans/pen/xQOgxx](https://codepen.io/pieter-biesemans/pen/xQOgxx).

Tired of writing JavaScript? Have you written your fair share of jQuery onclick events? <br> Despair not! For you can make a responsive gallery in just HTML and CSS. All you need are some labels and some exotic CSS. Have fun! 