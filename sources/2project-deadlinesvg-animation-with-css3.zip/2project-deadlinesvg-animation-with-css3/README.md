# #2 - Project Deadline - SVG animation with CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/jtrancozo/pen/mEoEVw](https://codepen.io/jtrancozo/pen/mEoEVw).

