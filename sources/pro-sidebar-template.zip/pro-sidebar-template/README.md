# Pro Sidebar template

A Pen created on CodePen.io. Original URL: [https://codepen.io/azouaoui-med/pen/wpBadb](https://codepen.io/azouaoui-med/pen/wpBadb).

Responsive layout with advanced sidebar menu built with SCSS and vanilla Javascript