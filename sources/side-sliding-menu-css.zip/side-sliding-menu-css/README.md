# Side Sliding Menu CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduardL/pen/jObzJB](https://codepen.io/EduardL/pen/jObzJB).

CSS Sliding menu with scroll, no JS were used