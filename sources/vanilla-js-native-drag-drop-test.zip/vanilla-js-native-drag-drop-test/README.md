# Vanilla JS Native Drag & Drop Test

A Pen created on CodePen.io. Original URL: [https://codepen.io/heyvian/pen/pWZZQL](https://codepen.io/heyvian/pen/pWZZQL).

Just learning and experimenting with HTML5 and JS drag & drop

- new <template> element
- pure JS no frameworks
- native drag & drop