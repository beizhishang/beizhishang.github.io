function dragstart_handler(ev) {
}
function dragover_handler(ev) {
 ev.preventDefault();
  console.log(this);
}
function drop_handler(ev) {
 ev.preventDefault();
  console.log(this);
  
}

var draggingType;

var itemTypes = document.querySelectorAll("[data-slide-type]");
console.log(itemTypes);

for (var i = 0, len = itemTypes.length; i < len; i++) {
  var itemType = itemTypes[i];
  var slideType;
  console.log(itemType);
  itemType.addEventListener("dragstart", function(ev) {
    var self = this;
    slideType = self.getAttribute("data-slide-type");
    draggingType = slideType;
    console.log(slideType);
  });
}

var dropZone = document.querySelector("[data-drop-zone]");
console.log(dropZone);
dropZone.addEventListener("dragover", function( event ) {
      // prevent default to allow drop
  //console.log("over");
      event.preventDefault();
  }, false);
dropZone.addEventListener("dragenter", function( event ) {
  console.log(this);
      // highlight potential drop target when the draggable element enters it
      if ( this.className == "c-drop-zone" ) { 
  console.log("enter");
          event.target.classList.toggle("targeted");
      }

  }, false);

dropZone.addEventListener("dragleave", function() {
 
          event.target.classList.toggle("targeted");

  }, false);

dropZone.addEventListener("drop", function( ev ) {
      // prevent default action (open as link for some elements)
      ev.preventDefault();
  var slideTemplate = document.querySelector('[data-slide-type-template="'+draggingType+'"');
  console.log('drop');
  var self = this;
  self.appendChild(slideTemplate.content.cloneNode(true));
})
