# CSS Grid: Floor Plan

A Pen created on CodePen.io. Original URL: [https://codepen.io/oliviale/pen/moLrBq](https://codepen.io/oliviale/pen/moLrBq).

Lots of empty space for the dogs and cats to walk around.