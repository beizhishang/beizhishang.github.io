# Gallery with wave transition effect.

A Pen created on CodePen.io. Original URL: [https://codepen.io/kiyutink/pen/XKvMjw](https://codepen.io/kiyutink/pen/XKvMjw).

It has 24 1920x1080 pictures inside, so it can take a few seconds to download. It looks cool though. Feel free to play around with variables (transition times and delays). You can also change the number of pictures. Just change the variables in scss and js. Also, if you want to add new pics, just add the urls of the pics in the js array. 