# Responsive gallery with automatic lightbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/Smackjax/pen/weYeWz](https://codepen.io/Smackjax/pen/weYeWz).

I wanted to make a lightbox.  So I decided to make a ridiculously easy lightbox, and this is what happened. 
It automatically generates a responsive gallery and loads the images asynchronously, connecting them to a lightbox. 

