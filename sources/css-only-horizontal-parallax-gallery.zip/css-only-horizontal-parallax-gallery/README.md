# CSS-Only Horizontal Parallax Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/pehaa/pen/zYxbxQg](https://codepen.io/pehaa/pen/zYxbxQg).

A few beautiful photos from Paris in this experimental gallery. Uses transforms together with perspective property for parallax.