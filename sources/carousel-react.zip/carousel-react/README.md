# Carousel (React)

A Pen created on CodePen.io. Original URL: [https://codepen.io/andyNroses/pen/KaENLb](https://codepen.io/andyNroses/pen/KaENLb).

Just trying out the CSSTransitionGroup add-on!