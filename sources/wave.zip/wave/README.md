# Wave

A Pen created on CodePen.io. Original URL: [https://codepen.io/katydecorah/pen/oNeZMN](https://codepen.io/katydecorah/pen/oNeZMN).

Throw ya hands in the ayyyer! I saw [this gif](http://imgur.com/gallery/0het78q) on reddit. Gasped. And ran to my computer.