/*
practicing grid positioning inspired by Windows 8 and experiment using webkit-scrollbar. 

use left and right arrow if you have difficulty finding the scrollbar in full view. 

best view in full view : https://codepen.io/ImBobby/full/ogxyj

Icons used in this pen by : http://www.iconarchive.com/show/windows-8-metro-icons-by-dakirby309.1.html

picture by : http://lorempixel.com

UPDATES:
28/09/2012: change hover effect. put animation for music and photos.
*/