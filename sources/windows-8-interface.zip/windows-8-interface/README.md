# Windows 8 Interface

A Pen created on CodePen.io. Original URL: [https://codepen.io/ImBobby/pen/DBaeXv](https://codepen.io/ImBobby/pen/DBaeXv).

practicing grid positioning inspired by Windows 8 and experiment using webkit-scrollbar. 

Icons used in this pen by : http://www.iconarchive.com/show/windows-8-metro-icons-by-dakirby309.1.html

picture by : http://lorempixel.com