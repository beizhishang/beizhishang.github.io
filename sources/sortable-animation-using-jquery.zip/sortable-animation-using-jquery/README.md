# Sortable Animation using Jquery

A Pen created on CodePen.io. Original URL: [https://codepen.io/dropinks/pen/MyoMJw](https://codepen.io/dropinks/pen/MyoMJw).

