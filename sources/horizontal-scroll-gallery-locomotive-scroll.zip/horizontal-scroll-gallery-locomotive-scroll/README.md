# Horizontal Scroll Gallery (Locomotive Scroll)

A Pen created on CodePen.io. Original URL: [https://codepen.io/sfi0zy/pen/PoGvYyy](https://codepen.io/sfi0zy/pen/PoGvYyy).

https://qna.habr.com/q/924265
