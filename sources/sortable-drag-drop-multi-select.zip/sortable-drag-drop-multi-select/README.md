# Sortable Drag & Drop Multi-Select

A Pen created on CodePen.io. Original URL: [https://codepen.io/santushDN/pen/WWeJeQ](https://codepen.io/santushDN/pen/WWeJeQ).

Bootstrap form comparable drag & drop multi-select create by Bootstrap, jQuery, jQuery Ui, jQuery Sortable.