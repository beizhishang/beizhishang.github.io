# Grid zoom

A Pen created on CodePen.io. Original URL: [https://codepen.io/fixcl/pen/dPXQRg](https://codepen.io/fixcl/pen/dPXQRg).

Very simple concept of image to display details.
use: Handlebars, Bootstrap grid and Velocity.
see: Firefox, Chrome (not very smooth)