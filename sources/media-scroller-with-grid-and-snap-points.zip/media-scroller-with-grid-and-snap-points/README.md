# Media Scroller with Grid and Snap Points

A Pen created on CodePen.io. Original URL: [https://codepen.io/argyleink/pen/jOrzEEM](https://codepen.io/argyleink/pen/jOrzEEM).

