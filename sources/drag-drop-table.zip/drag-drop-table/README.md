# Drag drop table

A Pen created on CodePen.io. Original URL: [https://codepen.io/umurkose/pen/wvYWgQm](https://codepen.io/umurkose/pen/wvYWgQm).

Resizable table with drag-drop reorder functionality using pure JavaScript and Tailwind CSS. This code covers process of implementing a drag-drop reorder feature to change the order of table rows, and a resizable table feature that allows users to resize columns.

Code explanation: https://onclick.blog/blog/creating-resizable-table-with-drag-drop-reorder-functionality-using-pure-javascript-and-tailwind-css