# P5 Matrix

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheBrutalTooth/pen/xxQBJpx](https://codepen.io/TheBrutalTooth/pen/xxQBJpx).

This is an old trick that I tried recreating tonight in p5, but I love the effect. Still working on an embedded array to transform things in action / on the way down. Hope you enjoy and feel free to use / edit / change as you wish ^_^