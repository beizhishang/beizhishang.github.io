/*
Resource: Interesting Facts On The Colour Blue - https://www.janelockhart.com/blog/interesting-facts-colour-blue/

*/