# Transparent Sidebar | CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/yLGeKXE](https://codepen.io/ecemgo/pen/yLGeKXE).

This pen includes an animated background by only using CSS, a transparent sidebar, and a responsive layout by using a CSS grid for cards. 