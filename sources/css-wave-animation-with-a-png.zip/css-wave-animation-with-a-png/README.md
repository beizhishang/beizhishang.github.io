# CSS Wave Animation with a .png

A Pen created on CodePen.io. Original URL: [https://codepen.io/plavookac/pen/QMwObb](https://codepen.io/plavookac/pen/QMwObb).

There was talk on our internal chat ( https://chat.vanila.io) about how https://itmeo.com/ have beautiful animation, and a member asked if someone can hack it. :) So I decide to examine their code and make just animation snippet code out of it.