# Info Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/nathantaylor/pen/WOgBQN](https://codepen.io/nathantaylor/pen/WOgBQN).

Design by Catalin V. (@hiskio https://twitter.com/hiskio) 
https://dribbble.com/shots/3408986-Info-Card-Daily-UI-045