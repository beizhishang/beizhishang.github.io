# It’s a Feature, not a Bug - CSS Grid Demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/stacy/pen/xjRyda](https://codepen.io/stacy/pen/xjRyda).

