# Timeline Style Navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/nailaahmad/pen/MyZXVE](https://codepen.io/nailaahmad/pen/MyZXVE).

