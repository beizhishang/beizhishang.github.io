# Text particle

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gthibaud/pen/pyeNKj](https://codepen.io/Gthibaud/pen/pyeNKj).

Text particle with canvas.
