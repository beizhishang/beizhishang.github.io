# Itchy Tanuki

A Pen created on CodePen.io. Original URL: [https://codepen.io/jasesmith/pen/pgdmdv](https://codepen.io/jasesmith/pen/pgdmdv).

A color experiment with Angular and HammerJS. 

Press the spacebar, or click refresh icon for a random color. Try dragging too!

Inspired by http://colorrrs.com/