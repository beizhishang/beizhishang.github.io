# HTML5 CSS-Driven Responsive Image Slider With Captions

A Pen created on CodePen.io. Original URL: [https://codepen.io/dudleystorey/pen/KKPdeb](https://codepen.io/dudleystorey/pen/KKPdeb).

Derivation of my [responsive slider technique](http://thenewcode.com/627/Make-A-Responsive-CSS3-Image-Slider) with frequently-asked-for captions. Code breakdown [on my blog](http://thenewcode.com/831/HTML5-Responsive-Image-Slider-With-Captions) Photographs by [Trey Ratcliff](http://www.flickr.com/photos/stuckincustoms/)