# lightgallery.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/sachinchoolur/pen/qNyvGW](https://codepen.io/sachinchoolur/pen/qNyvGW).

Full featured javascript lightbox gallery. No dependencies.