# Draggable List

A Pen created on CodePen.io. Original URL: [https://codepen.io/danielsintrao/pen/OgWJae](https://codepen.io/danielsintrao/pen/OgWJae).

