# Agency website POC

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/arQoER](https://codepen.io/jcoulterdesign/pen/arQoER).

A concept that was rejected by the client. Serves as a demo only and not to be put into production. Not responsive as just a POC

No  likey. No lighty