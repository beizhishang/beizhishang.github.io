# Owl Carousel 2 Navigation on Sides - Left and Right

A Pen created on CodePen.io. Original URL: [https://codepen.io/peshoto/pen/yxewzg](https://codepen.io/peshoto/pen/yxewzg).

