# Folding Profile Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/_Sabine/pen/xmoRqp](https://codepen.io/_Sabine/pen/xmoRqp).

100dayscss #013
#Gallery
###Folding picture gallery design
Playing around with picture filters & image overlay. Click to show user profile details.
Jquery, css transition