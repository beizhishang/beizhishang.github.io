$('.profile').click( function() {
	$('.detail').addClass('active');
});

$('.close').click( function() {
	$('.detail').removeClass('active');
});