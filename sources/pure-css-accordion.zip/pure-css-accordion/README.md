# Pure CSS Accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/raubaca/pen/PZzpVe](https://codepen.io/raubaca/pen/PZzpVe).

Accordion made with pure CSS. Based on the checkbox input+label trick to style active tabs.
