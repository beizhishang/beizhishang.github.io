# Another Gallery 

A Pen created on CodePen.io. Original URL: [https://codepen.io/nakome/pen/zYvJvJ](https://codepen.io/nakome/pen/zYvJvJ).

Responsive gallery with list style and custom lightbox.
Photos: unsplash.com.
