# Bootstrap video gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/tiemin/pen/pgabwE](https://codepen.io/tiemin/pen/pgabwE).

Referred from https://blueimp.github.io/Bootstrap-Image-Gallery/