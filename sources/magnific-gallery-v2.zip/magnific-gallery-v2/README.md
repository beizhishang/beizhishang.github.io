# Magnific Gallery V2

A Pen created on CodePen.io. Original URL: [https://codepen.io/mican/pen/RyjZgm](https://codepen.io/mican/pen/RyjZgm).

Responsive gallery with:
- CSS grid
- PhotoSwipe
- Lazysizes
- Pug, Sass & CoffeeScript