# Simple Website Builder

A Pen created on CodePen.io. Original URL: [https://codepen.io/asfo/pen/vKvvEb](https://codepen.io/asfo/pen/vKvvEb).

This is not a real website builder its just an idea I had and I want to complete.