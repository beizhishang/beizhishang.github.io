# Canvas Fireworks

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackrugile/pen/nExVvo](https://codepen.io/jackrugile/pen/nExVvo).

Click anywhere to launch fireworks. Click and drag to fire multiple fireworks. Settings can be adjusted in the top right. Be sure to try the presets. If things are running slow, try reducing reduce the partCount setting.

I recommend a full window size to work with the controls easier.