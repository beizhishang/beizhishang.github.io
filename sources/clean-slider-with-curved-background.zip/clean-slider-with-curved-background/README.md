# Clean Slider With Curved Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/mrspok407/pen/NRxBWa](https://codepen.io/mrspok407/pen/NRxBWa).

Based on dribbble shot by John Oates https://dribbble.com/shots/2936160-Opus-Animation