/*
  Saturn-like planet:
  
  Inspired by:
  http://upload.wikimedia.org/wikipedia/commons/3/39/Saturn%2C_Earth_size_comparison.jpg
  
  
  Note: on IE and Chrome it may be visible the clipping line at the center of the planet :(
  Firefox does not have this problem.
*/