# Saturn - pure CSS Planet

A Pen created on CodePen.io. Original URL: [https://codepen.io/Davide_sd/pen/QWrXjG](https://codepen.io/Davide_sd/pen/QWrXjG).

Inspired by a picture of planet Saturn.