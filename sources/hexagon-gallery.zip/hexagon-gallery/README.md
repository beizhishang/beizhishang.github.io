# Hexagon Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/gabrielajohnson/pen/EMVxEL](https://codepen.io/gabrielajohnson/pen/EMVxEL).

_Created for the [February 2019 CodePen Challenge](https://codepen.io/challenges/2019/February)_

CSS only Hexagon Gallery