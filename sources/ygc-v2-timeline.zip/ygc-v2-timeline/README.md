# YGC V2 Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/ygc/pen/rLbJdv](https://codepen.io/ygc/pen/rLbJdv).

