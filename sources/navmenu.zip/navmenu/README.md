# NavMenu

A Pen created on CodePen.io. Original URL: [https://codepen.io/MitchES/pen/dRMQdx](https://codepen.io/MitchES/pen/dRMQdx).

Expandble/collapsable navigational menu