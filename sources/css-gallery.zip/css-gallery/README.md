# CSS Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/heyDante/pen/bxEYOw](https://codepen.io/heyDante/pen/bxEYOw).

A simple css gallery that responds on hover.