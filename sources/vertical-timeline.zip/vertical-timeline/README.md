# Vertical Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/codyhouse/pen/OJgRvj](https://codepen.io/codyhouse/pen/OJgRvj).

An easy to customize, responsive timeline. We used some CSS3 tricks and a bit of jQuery to create some bounce animations that affect desktop users only, while on mobile the structure is more minimal.

Article and Download on Cody: http://codyhouse.co/gem/vertical-timeline/