# Modal Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/designcouch/pen/obvKxm](https://codepen.io/designcouch/pen/obvKxm).

Most of the time these slide in or fade in - just playing with other instantiation animations.

All animations are class-driven, and are animating the exact same HTML elements.