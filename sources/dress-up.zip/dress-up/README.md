# Dress Up

A Pen created on CodePen.io. Original URL: [https://codepen.io/pixelslave/pen/JjwjddP](https://codepen.io/pixelslave/pen/JjwjddP).

This pen uses CSS filters to change the color of the model's garments. I used JavaScript to calculate the offset for the CSS filter function and combined that with a color picker. Color availability and accuracy  aren't perfect because they work with a base color that isn't as neutral as it could be. I used an AI-generated model and I used ChatGPT to alphabetize my SCSS properties because, why not use AI to achieve perfection when we can?