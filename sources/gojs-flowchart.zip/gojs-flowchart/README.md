# gojs flowchart

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nirtz89/pen/aJBOMq](https://codepen.io/Nirtz89/pen/aJBOMq).

